﻿using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Snake_Game
{
    public partial class Form1 : Form
    {
        private int score;
        private int highScore;
        private int cellsize = 20;
        private string direction = "Right";
        private List<Point> snake = new List<Point>();
        private Point food;
        private Random rand = new Random();
        private bool isPaused = false;
        private Color snakeColor = Color.Red;
        private Color foodColor = Color.Blue;

        private void GameOver()
        {
            gameTimer.Stop();

            lblFinalScore.Text = "Final Score:   " + score;
            pnlGameOver.Visible = true;
            btnPause.Enabled = false;
        }

        private void GenerateFood()
        {
            int maxX = pnlgame.Width / cellsize;
            int maxY = pnlgame.Height / cellsize;

            Point newFood;

            do
            {
                newFood = new Point(rand.Next(0, maxX), rand.Next(0, maxY));
            }
            while (snake.Contains(newFood));

            food = newFood;
        }

        private void MoveSnake()
        {
            Point head = snake[0];
            Point newHead = head;

            switch (direction)
            {
                case "Up":
                    newHead.Y -= 1;
                    break;
                case "Down":
                    newHead.Y += 1;
                    break;
                case "Left":
                    newHead.X -= 1;
                    break;
                case "Right":
                    newHead.X += 1;
                    break;
            }

            // Head add
            snake.Insert(0, newHead);

            // Tail remove
            snake.RemoveAt(snake.Count - 1);
        }

        private void CheckFoodCollision()
        {
            if (snake[0].X == food.X && snake[0].Y == food.Y)
            {
                // Snake grow temporary tail, next tick me adjust
                snake.Add(new Point(-1, -1));

                // Score update
                score += 10;
                lblScore.Text = "Score:   " + score;

                // High score update
                if (score > highScore)
                {
                    highScore = score;
                    lblHighScore.Text = "High Score:   " + highScore;
                }

                // Generate new food
                GenerateFood();
            }
        }

        private void CheckCollision()
        {
            Point head = snake[0];

            // Wall collision
            if (head.X < 0 || head.X >= pnlgame.Width / cellsize ||
                head.Y < 0 || head.Y >= pnlgame.Height / cellsize)
            {
                GameOver();
            }

            // Self collision
            for (int i = 1; i < snake.Count; i++)
            {
                if (head == snake[i])
                {
                    GameOver();
                }
            }
        }

        private void InitializeSnake()
        {
            snake.Clear();
            // Head
            snake.Add(new Point(5, 5));
            snake.Add(new Point(4, 5));
            snake.Add(new Point(3, 5));

            // Score reset
            score = 0;
            lblScore.Text = "Score:  " + score;
        }


        public Form1()
        {
            InitializeComponent();

            pnlgame.GetType()
            .GetProperty("DoubleBuffered", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
            ?.SetValue(pnlgame, true);
            
            gameTimer.Tick += gameTimer_Tick;
            this.KeyPreview = true;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            pnlStart.Visible = false;
            pnlGameOver.Visible = false;

            // Initialize game
            score = 0;
            highScore = 0;
            lblScore.Text = "Score:  " + score;
            lblHighScore.Text = "High Score:   " + highScore;

            InitializeSnake();
            GenerateFood();

            pnlgame.Visible = true;
            panel1.Visible = true;
            btnPause.Enabled = true;

            pnlgame.Invalidate();

            pnlgame.Focus();

            // Start timer
            gameTimer.Start();
        }

        private void gameTimer_Tick(object? sender, EventArgs e)
        {
            // Snake ko move kare
            MoveSnake();

            // Wall ya self collision check
            CheckCollision();

            // Food khane pe grow + score
            CheckFoodCollision();

            // Panel redraw
            pnlgame.Invalidate();
        }

        private void pnlgame_Paint(object sender, PaintEventArgs e)
        {
            int rows = pnlgame.Height / cellsize;
            int cols = pnlgame.Width / cellsize;

            using (Pen pen = new Pen(Color.LightGray))
            {
                // Horizontal lines
                for (int i = 0; i <= rows; i++)
                {
                    e.Graphics.DrawLine(pen, 0, i * cellsize, pnlgame.Width, i * cellsize);
                }

                // Vertical lines
                for (int j = 0; j <= cols; j++)
                {
                    e.Graphics.DrawLine(pen, j * cellsize, 0, j * cellsize, pnlgame.Height);
                }
            }

            // Draw snake
            using (Brush snakeBrush = new SolidBrush(snakeColor))
            {
                foreach (var segment in snake)
                    e.Graphics.FillRectangle(snakeBrush, segment.X * cellsize, segment.Y * cellsize, cellsize, cellsize);
            }

            // Draw food
            using (Brush foodBrush = new SolidBrush(foodColor))
            {
                e.Graphics.FillRectangle(foodBrush, food.X * cellsize, food.Y * cellsize, cellsize, cellsize);
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            // Up Arrow
            if (e.KeyCode == Keys.Up)
            {
                if (direction != "Down")
                    direction = "Up";
            }

            // Down Arrow
            if (e.KeyCode == Keys.Down)
            {
                if (direction != "Up")
                    direction = "Down";
            }

            // Left Arrow
            if (e.KeyCode == Keys.Left)
            {
                if (direction != "Right")
                    direction = "Left";
            }

            // Right Arrow
            if (e.KeyCode == Keys.Right)
            {
                if (direction != "Left")
                    direction = "Right";
            }
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            if (isPaused)
            {
                gameTimer.Start();
                btnPause.Text = "Pause";
                isPaused = false;
            }
            else
            {
                gameTimer.Stop();
                btnPause.Text = "Resume";
                isPaused = true;
            }
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            // Stop previous timer
            gameTimer.Stop();

            pnlGameOver.Visible = false;
            pnlStart.Visible = false;
            pnlgame.Visible = true;

            panel1.Visible = true;
            btnPause.Enabled = true;

            //Reset game values
            score = 0;
            lblScore.Text = "Score:  " + score;
            lblHighScore.Text = "High Score:  " + highScore;
            direction = "Right";

            // Reset snake
            InitializeSnake();

            // Generate fresh food
            GenerateFood();

            pnlgame.Invalidate();

            pnlgame.Focus();

            // Reset timer speed
            gameTimer.Interval = 300;

            // Start again
            gameTimer.Start();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void lblSetting_Click(object sender, EventArgs e)
        {
            contextMenuStrip2.Show(lblSetting, new Point(0, lblSetting.Height));
        }

        private void snakeColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (ColorDialog cd = new ColorDialog())
            {
                if (cd.ShowDialog() == DialogResult.OK)
                {
                    snakeColor = cd.Color;
                    pnlgame.Invalidate();
                }
            }
        }

        private void foodColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (ColorDialog cd = new ColorDialog())
            {
                if (cd.ShowDialog() == DialogResult.OK)
                {
                    foodColor = cd.Color;
                    pnlgame.Invalidate();
                }
            }
        }
    }
}