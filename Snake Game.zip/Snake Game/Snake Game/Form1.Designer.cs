﻿namespace Snake_Game
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            pnlStart = new Panel();
            lblSetting = new Label();
            lblName = new Label();
            label1 = new Label();
            btnStart = new Button();
            pnlGameOver = new Panel();
            btnExit = new Button();
            btnRestart = new Button();
            lblFinalScore = new Label();
            lblGameOver = new Label();
            pnlgame = new Panel();
            lblHighScore = new Label();
            lblScore = new Label();
            btnPause = new Button();
            panel1 = new Panel();
            contextMenuStrip2 = new ContextMenuStrip(components);
            snakeColorToolStripMenuItem = new ToolStripMenuItem();
            foodColorToolStripMenuItem = new ToolStripMenuItem();
            gameTimer = new System.Windows.Forms.Timer(components);
            pnlStart.SuspendLayout();
            pnlGameOver.SuspendLayout();
            pnlgame.SuspendLayout();
            panel1.SuspendLayout();
            contextMenuStrip2.SuspendLayout();
            SuspendLayout();
            // 
            // pnlStart
            // 
            pnlStart.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pnlStart.BackColor = SystemColors.ActiveCaption;
            pnlStart.BorderStyle = BorderStyle.FixedSingle;
            pnlStart.Controls.Add(lblSetting);
            pnlStart.Controls.Add(lblName);
            pnlStart.Controls.Add(label1);
            pnlStart.Controls.Add(btnStart);
            pnlStart.Location = new Point(232, 63);
            pnlStart.Name = "pnlStart";
            pnlStart.Size = new Size(478, 434);
            pnlStart.TabIndex = 0;
            // 
            // lblSetting
            // 
            lblSetting.BorderStyle = BorderStyle.FixedSingle;
            lblSetting.Font = new Font("Segoe UI", 20F);
            lblSetting.Location = new Point(37, 336);
            lblSetting.Name = "lblSetting";
            lblSetting.Size = new Size(68, 61);
            lblSetting.TabIndex = 5;
            lblSetting.Text = "⚙️";
            lblSetting.TextAlign = ContentAlignment.MiddleCenter;
            lblSetting.Click += lblSetting_Click;
            // 
            // lblName
            // 
            lblName.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblName.Font = new Font("Algerian", 35F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblName.ForeColor = SystemColors.ActiveCaptionText;
            lblName.Location = new Point(66, 81);
            lblName.Name = "lblName";
            lblName.Size = new Size(348, 94);
            lblName.TabIndex = 2;
            lblName.Text = "Snake Game ";
            lblName.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label1.Location = new Point(49, 152);
            label1.Name = "label1";
            label1.Size = new Size(392, 161);
            label1.TabIndex = 1;
            label1.Text = "Use arrow keys to move the snake. Press Start to play.";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnStart
            // 
            btnStart.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            btnStart.BackColor = Color.FromArgb(255, 128, 128);
            btnStart.FlatStyle = FlatStyle.Flat;
            btnStart.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btnStart.Location = new Point(111, 336);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(315, 61);
            btnStart.TabIndex = 0;
            btnStart.Text = "Start";
            btnStart.UseVisualStyleBackColor = false;
            btnStart.Click += btnStart_Click;
            // 
            // pnlGameOver
            // 
            pnlGameOver.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pnlGameOver.BackColor = SystemColors.ActiveCaption;
            pnlGameOver.BorderStyle = BorderStyle.FixedSingle;
            pnlGameOver.Controls.Add(btnExit);
            pnlGameOver.Controls.Add(btnRestart);
            pnlGameOver.Controls.Add(lblFinalScore);
            pnlGameOver.Controls.Add(lblGameOver);
            pnlGameOver.Location = new Point(250, 32);
            pnlGameOver.Name = "pnlGameOver";
            pnlGameOver.Size = new Size(478, 429);
            pnlGameOver.TabIndex = 1;
            pnlGameOver.Visible = false;
            // 
            // btnExit
            // 
            btnExit.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            btnExit.BackColor = Color.DarkCyan;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btnExit.Location = new Point(68, 346);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(335, 61);
            btnExit.TabIndex = 7;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // btnRestart
            // 
            btnRestart.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            btnRestart.BackColor = Color.DodgerBlue;
            btnRestart.FlatStyle = FlatStyle.Flat;
            btnRestart.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btnRestart.Location = new Point(68, 256);
            btnRestart.Name = "btnRestart";
            btnRestart.Size = new Size(335, 61);
            btnRestart.TabIndex = 6;
            btnRestart.Text = "Restart";
            btnRestart.UseVisualStyleBackColor = false;
            btnRestart.Click += btnRestart_Click;
            // 
            // lblFinalScore
            // 
            lblFinalScore.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblFinalScore.Font = new Font("Segoe UI", 17F, FontStyle.Bold);
            lblFinalScore.Location = new Point(101, 124);
            lblFinalScore.Name = "lblFinalScore";
            lblFinalScore.Size = new Size(254, 92);
            lblFinalScore.TabIndex = 5;
            lblFinalScore.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblGameOver
            // 
            lblGameOver.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblGameOver.Font = new Font("Algerian", 30F, FontStyle.Bold);
            lblGameOver.ForeColor = Color.Red;
            lblGameOver.Location = new Point(52, 14);
            lblGameOver.Name = "lblGameOver";
            lblGameOver.Size = new Size(351, 142);
            lblGameOver.TabIndex = 4;
            lblGameOver.Text = "Game Over !";
            lblGameOver.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pnlgame
            // 
            pnlgame.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pnlgame.BackColor = SystemColors.WindowText;
            pnlgame.BorderStyle = BorderStyle.FixedSingle;
            pnlgame.Controls.Add(pnlGameOver);
            pnlgame.Location = new Point(0, 44);
            pnlgame.Name = "pnlgame";
            pnlgame.Size = new Size(929, 525);
            pnlgame.TabIndex = 1;
            pnlgame.Visible = false;
            pnlgame.Paint += pnlgame_Paint;
            // 
            // lblHighScore
            // 
            lblHighScore.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            lblHighScore.BackColor = Color.Transparent;
            lblHighScore.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblHighScore.Location = new Point(398, 6);
            lblHighScore.Name = "lblHighScore";
            lblHighScore.Size = new Size(164, 33);
            lblHighScore.TabIndex = 3;
            lblHighScore.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblScore
            // 
            lblScore.BackColor = Color.Transparent;
            lblScore.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblScore.Location = new Point(27, 6);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(132, 34);
            lblScore.TabIndex = 2;
            lblScore.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // btnPause
            // 
            btnPause.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnPause.BackColor = Color.SkyBlue;
            btnPause.Enabled = false;
            btnPause.FlatStyle = FlatStyle.Flat;
            btnPause.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btnPause.ForeColor = Color.Black;
            btnPause.Location = new Point(789, 3);
            btnPause.Name = "btnPause";
            btnPause.Size = new Size(135, 39);
            btnPause.TabIndex = 1;
            btnPause.Text = "Pause";
            btnPause.UseVisualStyleBackColor = false;
            btnPause.Click += btnPause_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.LightGray;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(lblScore);
            panel1.Controls.Add(btnPause);
            panel1.Controls.Add(lblHighScore);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(929, 47);
            panel1.TabIndex = 2;
            panel1.Visible = false;
            // 
            // contextMenuStrip2
            // 
            contextMenuStrip2.Items.AddRange(new ToolStripItem[] { snakeColorToolStripMenuItem, foodColorToolStripMenuItem });
            contextMenuStrip2.Name = "contextMenuStrip2";
            contextMenuStrip2.Size = new Size(138, 48);
            // 
            // snakeColorToolStripMenuItem
            // 
            snakeColorToolStripMenuItem.Name = "snakeColorToolStripMenuItem";
            snakeColorToolStripMenuItem.Size = new Size(137, 22);
            snakeColorToolStripMenuItem.Text = "Snake Color";
            snakeColorToolStripMenuItem.Click += snakeColorToolStripMenuItem_Click;
            // 
            // foodColorToolStripMenuItem
            // 
            foodColorToolStripMenuItem.Name = "foodColorToolStripMenuItem";
            foodColorToolStripMenuItem.Size = new Size(137, 22);
            foodColorToolStripMenuItem.Text = "Food Color";
            foodColorToolStripMenuItem.Click += foodColorToolStripMenuItem_Click;
            // 
            // gameTimer
            // 
            gameTimer.Interval = 300;
            gameTimer.Tick += gameTimer_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveBorder;
            BackgroundImage = Properties.Resources.Snake_img;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(929, 569);
            Controls.Add(pnlStart);
            Controls.Add(panel1);
            Controls.Add(pnlgame);
            Cursor = Cursors.IBeam;
            Font = new Font("Segoe UI", 10F);
            Icon = (Icon)resources.GetObject("$this.Icon");
            KeyPreview = true;
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Snake Game ";
            KeyDown += Form1_KeyDown;
            pnlStart.ResumeLayout(false);
            pnlGameOver.ResumeLayout(false);
            pnlgame.ResumeLayout(false);
            panel1.ResumeLayout(false);
            contextMenuStrip2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlStart;
        private Button btnPause;
        private Button btnStart;
        private Label lblScore;
        private Label lblHighScore;
        private Panel pnlgame;
        private Label lblGameOver;
        private Panel panel1;
        private Label label1;
        private Panel pnlGameOver;
        private Label lblFinalScore;
        private Button btnRestart;
        private Label lblName;
        private System.Windows.Forms.Timer gameTimer;
        private Button btnExit;
        private ContextMenuStrip contextMenuStrip2;
        private ToolStripMenuItem snakeColorToolStripMenuItem;
        private ToolStripMenuItem foodColorToolStripMenuItem;
        private Label lblSetting;
    }
}
